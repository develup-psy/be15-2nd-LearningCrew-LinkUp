package com.learningcrew.linkup.linker.command.domain.constants;

public enum LinkerGender {
    M, F, BOTH
}
