package com.learningcrew.linkup.notification.command.domain.aggregate;

public enum NotificationReadStatus {
    Y,  // 읽음
    N   // 안 읽음
}