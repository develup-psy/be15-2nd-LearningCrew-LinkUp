package com.learningcrew.linkup.linker.command.application.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("")
public class AccountCommandController {
    /* 계좌 등록 */

    /* 사업자 등록 */
}
