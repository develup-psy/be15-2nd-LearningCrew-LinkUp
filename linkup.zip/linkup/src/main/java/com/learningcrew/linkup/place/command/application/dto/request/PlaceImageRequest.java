package com.learningcrew.linkup.place.command.application.dto.request;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.RequiredArgsConstructor;

@Getter
@NoArgsConstructor
public class PlaceImageRequest {
    private String imageUrl;
}
