package com.learningcrew.linkup.linker.command.domain.constants;

public enum EmailTokenType {
    REGISTER,
    RESET_PASSWORD,
    ACCOUNT_RECOVERY
}
