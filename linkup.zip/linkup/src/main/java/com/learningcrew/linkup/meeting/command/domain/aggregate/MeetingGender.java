package com.learningcrew.linkup.meeting.command.domain.aggregate;

public enum MeetingGender {
    M, F, BOTH
}
