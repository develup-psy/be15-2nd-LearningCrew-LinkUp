package com.learningcrew.linkup.common.dto.query;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class StatusDTO {
    private int statusId;
    private String statusType;
}
