package com.learningcrew.linkup.report.command.domain.aggregate;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum PenaltyType {
    POST, COMMENT, REVIEW
}
