package com.learningcrew.linkup.meeting.command.domain.repository;

public interface BestPlayerRepository {
}
