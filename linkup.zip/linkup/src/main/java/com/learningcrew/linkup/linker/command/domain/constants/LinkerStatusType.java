package com.learningcrew.linkup.linker.command.domain.constants;

public enum LinkerStatusType {
    PENDING, ACCEPTED, REJECTED, DELETED;
}
