package com.learningcrew.linkup.linker.command.domain.constants;

public enum LinkerIsActive {
    Y, N
}
