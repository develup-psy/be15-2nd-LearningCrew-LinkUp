package com.learningcrew.linkup.common.dto.query;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class RoleDTO {
    private int roleId;
    private String roleName;
}
