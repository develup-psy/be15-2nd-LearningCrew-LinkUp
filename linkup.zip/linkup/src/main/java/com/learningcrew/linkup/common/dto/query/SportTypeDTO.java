package com.learningcrew.linkup.common.dto.query;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SportTypeDTO {
    private int sportTypeId;
    private String sportName;
}