package com.learningcrew.linkup.meeting.command.application.dto.request;

import lombok.Getter;

@Getter
public class ManageParticipationRequest {
    private int memberId;
}
