package com.learningcrew.linkup.meeting.query.dto.response;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class InterestedMeetingDTO {
    private int meetingId;
    private int memberId;
}
