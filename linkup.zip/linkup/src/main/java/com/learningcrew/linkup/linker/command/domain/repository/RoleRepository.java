package com.learningcrew.linkup.linker.command.domain.repository;

import com.learningcrew.linkup.common.domain.Role;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RoleRepository extends JpaRepository<Role, Integer> {

}
