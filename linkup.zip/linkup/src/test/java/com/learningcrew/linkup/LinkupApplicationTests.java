package com.learningcrew.linkup;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LinkupApplicationTests {

	@Test
	void contextLoads() {
	}

}
