package com.learningcrew.linkup.meeting.command.application.service;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class MeetingCommandServiceTest {

    @Test
    void createMeeting() {


    }
}